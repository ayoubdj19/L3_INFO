#ifndef __TEXTE__
#define __TEXTE__

void demarrer();
void avancer();
char courant();
int fin();

#endif
